package com.swin.anticheatanalyzer

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.content.pm.PackageManager
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 13, 16)
    private val panel = Color.rgb(27, 27, 33)
    private val red = Color.rgb(235, 55, 65)
    private val muted = Color.rgb(165, 165, 175)
    private lateinit var results: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        runDiagnostics()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }

        val brand = TextView(this).apply {
            text = "SWIN // DEVICE SECURITY"
            setTextColor(red)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            letterSpacing = 0.12f
        }
        page.addView(brand)

        val title = TextView(this).apply {
            text = "ANTI-CHEAT\nANALYZER"
            setTextColor(Color.WHITE)
            textSize = 30f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(8))
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "Локальная диагностика устройства"
            setTextColor(muted)
            textSize = 14f
        }
        page.addView(subtitle)

        status = TextView(this).apply {
            text = "●  INITIALIZING"
            setTextColor(red)
            textSize = 15f
            typeface = Typeface.MONOSPACE
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        val statusParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        statusParams.topMargin = dp(22)
        page.addView(status, statusParams)

        val scanButton = Button(this).apply {
            text = "RUN FULL SCAN"
            setTextColor(Color.WHITE)
            setBackgroundColor(red)
            isAllCaps = false
            textSize = 15f
            setOnClickListener { runDiagnostics() }
        }
        val buttonParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(54)
        )
        buttonParams.topMargin = dp(14)
        page.addView(scanButton, buttonParams)

        val section = TextView(this).apply {
            text = "DIAGNOSTIC REPORT"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(26), 0, dp(12))
        }
        page.addView(section)

        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(results)

        val footer = TextView(this).apply {
            text = "INFO  •  Проверки выполняются локально. Приложение не подключается к PUBG Mobile, не читает память игры и не изменяет её файлы."
            setTextColor(muted)
            textSize = 12f
            setPadding(0, dp(22), 0, 0)
        }
        page.addView(footer)
        scroll.addView(page)
        setContentView(scroll)
    }

    private data class Finding(val title: String, val detail: String, val warning: Boolean)

    private fun runDiagnostics() {
        results.removeAllViews()
        status.text = "●  SCANNING..."
        val findings = mutableListOf<Finding>()

        val rooted = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/system/app/Superuser.apk", "/system/bin/.ext/.su"
        ).any { File(it).exists() }
        findings += Finding(
            "ROOT INDICATORS",
            if (rooted) "Обнаружен один или несколько известных root-индикаторов."
            else "Известные root-файлы не обнаружены. Это не доказывает отсутствие root.",
            rooted
        )

        val testKeys = Build.TAGS?.contains("test-keys", ignoreCase = true) == true
        findings += Finding(
            "BUILD TAGS",
            "Build.TAGS = ${Build.TAGS ?: "unknown"}",
            testKeys
        )

        val debugger = Debug.isDebuggerConnected() || Debug.waitingForDebugger()
        findings += Finding(
            "DEBUGGER",
            if (debugger) "К приложению подключён отладчик."
            else "Отладчик к этому приложению не подключён.",
            debugger
        )

        val emulator = isProbablyEmulator()
        findings += Finding(
            "VIRTUAL DEVICE",
            if (emulator) "Обнаружены типичные признаки эмулятора."
            else "Типичные признаки эмулятора не обнаружены.",
            emulator
        )

        findings += Finding(
            "ANDROID BUILD",
            "${Build.MANUFACTURER} ${Build.MODEL} • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            false
        )

        val apkDigest = try {
            sha256(File(applicationInfo.sourceDir))
        } catch (e: Exception) {
            "Не удалось вычислить: ${e.javaClass.simpleName}"
        }
        findings += Finding("APP APK SHA-256", apkDigest, false)

        val nativeDir = applicationInfo.nativeLibraryDir?.let { File(it) }
        val nativeFiles = nativeDir?.listFiles()
            ?.filter { it.isFile && it.extension.equals("so", true) }
            .orEmpty()
        findings += Finding(
            "APP NATIVE LIBRARIES",
            if (nativeFiles.isEmpty()) "В каталоге нативных библиотек приложения .so не найдено."
            else nativeFiles.joinToString("\n") { "${it.name}  •  ${runCatching { sha256(it) }.getOrDefault("hash error")}" },
            false
        )

        findings.forEach { addFinding(it) }
        val warnings = findings.count { it.warning }
        status.text = if (warnings == 0) "●  SCAN COMPLETE  •  $warnings FLAGS"
                      else "●  SCAN COMPLETE  •  $warnings FLAGS"
        status.setTextColor(if (warnings == 0) Color.rgb(90, 210, 130) else red)
        status.contentDescription = "Проверка завершена. Индикаторов: $warnings"
    }

    private fun addFinding(finding: Finding) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            setBackgroundColor(panel)
        }
        val heading = TextView(this).apply {
            text = (if (finding.warning) "▲  " else "●  ") + finding.title
            setTextColor(if (finding.warning) red else Color.rgb(100, 210, 145))
            textSize = 13f
            typeface = Typeface.MONOSPACE
        }
        val detail = TextView(this).apply {
            text = finding.detail
            setTextColor(Color.rgb(220, 220, 225))
            textSize = 13f
            setPadding(0, dp(8), 0, 0)
        }
        card.addView(heading)
        card.addView(detail)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = dp(9)
        results.addView(card, params)
    }

    private fun isProbablyEmulator(): Boolean {
        val fingerprint = Build.FINGERPRINT.orEmpty()
        val model = Build.MODEL.orEmpty()
        val product = Build.PRODUCT.orEmpty()
        val hardware = Build.HARDWARE.orEmpty()
        return fingerprint.startsWith("generic") ||
            fingerprint.contains("virtual", true) ||
            model.contains("Emulator", true) ||
            model.contains("Android SDK built for", true) ||
            product.contains("sdk", true) ||
            hardware.contains("goldfish", true) ||
            hardware.contains("ranchu", true)
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
